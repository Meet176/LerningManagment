package com.mg.serviceImpl;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.stereotype.Service;

import com.mg.DTO.EnrollmentDTO;
import com.mg.entity.Coupen;
import com.mg.entity.CourseEntity;
import com.mg.entity.Enrollment;
import com.mg.entity.UserEntity;
import com.mg.enums.DiscountType;
import com.mg.exception.ResourceNotFoundException;
import com.mg.mapper.EnrollmentMapper;
import com.mg.repository.CoupenRepository;
import com.mg.repository.CourseRepository;
import com.mg.repository.EnrollmentRepository;
import com.mg.repository.UserRepository;
import com.mg.service1.EnrollmentService;

@Service
public class EnrollmentServiceImpl implements EnrollmentService 
{
		@Autowired
		private EnrollmentRepository enrollRepository;
		
		@Autowired
		private CourseRepository courseRepo;

		@Autowired
		private EnrollmentMapper mapper;
		
		@Autowired
		private UserRepository userRepo;
		
		@Autowired
		private CoupenRepository coupenRepo;
		
		
	@Override
	public List<EnrollmentDTO> getAllEnrollment() 
	{
		return enrollRepository.findAll()
				.stream()
				.map(mapper::toDto)
				.collect(Collectors.toList());
	}

	@Override
	public List<EnrollmentDTO> getActiveEnrollment() 
	{
		return enrollRepository.findByDeletedDateIsNull()
				.stream()
				.map(mapper::toDto)
				.collect(Collectors.toList());
	}

	@Override
	public EnrollmentDTO createEnrollment(EnrollmentDTO dto) 
	{
		CourseEntity course =  courseRepo.findById(dto.getCourseID())
			.orElseThrow(()-> new ResourceNotFoundException("The Course Not Found here..."));
		
		UserEntity user = userRepo.findById(dto.getUserId())
					.orElseThrow(()-> new ResourceNotFoundException("The User Not Found..."));
		
		 BigDecimal finalPrice = course.getPrice();
		 
		 //Apply Coupan If Exisist
		 
		 if(dto.getCouponCode() != null && !dto.getCouponCode().isEmpty())
		 {
			  Coupen coupon = coupenRepo.findByCode(dto.getCouponCode())
		                .orElseThrow(() -> new RuntimeException("Invalid coupon code"));
			  
			  if(coupon.getExpiryDate().isBefore(LocalDateTime.now()))
			  {
				  	throw  new ResourceNotFoundException("Coupen IS Expire");
			  }
			  
			  
			  BigDecimal discount = coupon.getDiscountAmount();
			  
			  if(coupon.getDiscountType()== DiscountType.Percentage)
			  {
				  BigDecimal percentage = discount.divide(BigDecimal.valueOf(100));
				  
				  finalPrice = finalPrice.subtract(finalPrice.multiply(percentage));
			  }
			  else
			  {
				  finalPrice = finalPrice.subtract(discount);
			  }
			  
			  
			  // Avoid negative prices
	            if (finalPrice.compareTo(BigDecimal.ZERO) < 0) {
	                finalPrice = BigDecimal.ZERO;
	            }

		 }
		
		return mapper.toDto(enrollRepository.save(mapper.toEntity(dto, user, course)));
	}

	@Override
	public EnrollmentDTO updateEnrollment(Long id, EnrollmentDTO dto) 
	{
		Enrollment enroll = enrollRepository.findById(id)
		.orElseThrow(()-> new ResourceNotFoundException("The Data Not Found To Update"));
		
		UserEntity user = userRepo.findById(id)
				.orElseThrow(()-> new ResourceNotFoundException("The Data Not Found To Update"));
		
		
		CourseEntity course = courseRepo.findById(id)
				.orElseThrow(()-> new ResourceNotFoundException("The Data Not Found To Update"));
		
		
		enroll.setIsCompleted(dto.getIsCompleted());
		enroll.setPrice(dto.getPrice());
		enroll.setPaymentMethod(dto.getPaymentMethod());
		
		
		return mapper.toDto(enrollRepository.save(mapper.toEntity(dto, user, course)));
	}

	@Override
	public void deleteEnrollment(Long id) 
	{
			Enrollment enroll = enrollRepository.findById(id)
				.orElseThrow(()-> new ResourceNotFoundException("The Data Not Found to Delete.."));
			
			enroll.setDeletedDate(LocalDateTime.now());
			
			enrollRepository.save(enroll);
	}

	 	@Override
	 public Enrollment restoreEnrollment(Long id) 
	 {
	        Enrollment enrollment = enrollRepository.findById(id)
	                .orElseThrow(() -> new RuntimeException("Enrollment not found"));
	        enrollment.setDeletedDate(null);
	        return enrollRepository.save(enrollment);
	    }

}
