package com.mg.serviceImpl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.mg.DTO.CourseContentDTO;
import com.mg.DTO.SequenceUpdateRequest;
import com.mg.entity.CourseContent;
import com.mg.entity.CourseModule;
import com.mg.exception.ResourceNotFoundException;
import com.mg.mapper.CourseContentMapper;
import com.mg.repository.CourseContentRepository;
import com.mg.repository.CourseModuleRepository;
import com.mg.service1.CourseContentService;

import jakarta.transaction.Transactional;

@Service
public class CourseContentServiceImpl implements CourseContentService {

    @Autowired
    private CourseContentRepository contentRepo;

    @Autowired
    private CourseModuleRepository moduleRepo;

    @Autowired
    private CourseContentMapper mapper;

    private static final String FILE_UPLOAD_DIR = "uploads/modules/";

    @Override
    public CourseContentDTO createContent(CourseContentDTO dto) throws IOException {
        CourseModule module = moduleRepo.findById(dto.getModuleId())
            .orElseThrow(() -> new ResourceNotFoundException("Module not found"));

        CourseContent content = mapper.toEntity(dto, module,null);

        MultipartFile file = dto.getFilepath();
        if (file != null && !file.isEmpty()) {
            String filename = UUID.randomUUID() + "_" + file.getOriginalFilename();
            Path path = Paths.get(FILE_UPLOAD_DIR + filename);
            Files.createDirectories(path.getParent());
            Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
            content.setFilePath(filename);
        }

        CourseContent saved = contentRepo.save(content);
        updateModuleStats(module.getId());
        return mapper.toDTO(saved);
    }

    @Override
    public List<CourseContentDTO> getByModuleId(Long moduleId) {
        List<CourseContent> contents = contentRepo.findByCourseModule_IdAndDeletedDateIsNull(moduleId);
        return contents.stream()
                .map(mapper::toDTO)
                .collect(Collectors.toList());
    }

    @Override
    public CourseContentDTO updateContent(Long id, CourseContentDTO dto) throws IOException {
        CourseContent content = contentRepo.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Content not found"));

        content.setTitle(dto.getTitle());
        content.setSequence(dto.getSequence());
        content.setFileType(dto.getFileType());
        content.setDurationMinutes(dto.getDurationMinutes());

        MultipartFile file = dto.getFilepath();
        if (file != null && !file.isEmpty()) {
            String filename = UUID.randomUUID() + "_" + file.getOriginalFilename();
            Path path = Paths.get(FILE_UPLOAD_DIR + filename);
            Files.createDirectories(path.getParent());
            Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
            content.setFilePath(filename);
        }

        CourseContent updated = contentRepo.save(content);
        updateModuleStats(updated.getCourseModule().getId());
        return mapper.toDTO(updated);
    }

    @Override
    public void Delete(Long id) {
        CourseContent content = contentRepo.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Content not found"));
        contentRepo.delete(content);
    }

    @Override
    public void softDelete(Long id) {
        CourseContent content = contentRepo.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Content not found"));
        content.setDeletedDate(LocalDateTime.now());
        contentRepo.save(content);
    }

    @Override
    public CourseContentDTO restore(Long id) {
        CourseContent content = contentRepo.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Content not found"));
        content.setDeletedDate(null);
        CourseContent restored = contentRepo.save(content);
        return mapper.toDTO(restored);
    }

    @Override
    public void updateSequence(Long id, Integer sequence) {
        CourseContent content = contentRepo.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Content not found"));
        content.setSequence(sequence);
        contentRepo.save(content);
    }

    @Override
    @Transactional
    public void updateSequence(List<SequenceUpdateRequest> requestList) {
        for (SequenceUpdateRequest req : requestList) {
            CourseContent content = contentRepo.findById(req.getId())
                .orElseThrow(() -> new ResourceNotFoundException("Content not found with ID: " + req.getId()));
            content.setSequence(req.getSequence());
            contentRepo.save(content);
        }
    }

    // 🔄 Update content count and total duration
    private void updateModuleStats(Long moduleId) {
        CourseModule module = moduleRepo.findById(moduleId)
            .orElseThrow(() -> new ResourceNotFoundException("Module not found"));

        List<CourseContent> contents = contentRepo.findByCourseModule_IdAndDeletedDateIsNull(moduleId);

        int contentCount = contents.size();
        int totalMinutes = contents.stream()
            .mapToInt(c -> c.getDurationMinutes() != null ? c.getDurationMinutes() : 0)
            .sum();

        module.setContentCount(contentCount);
        module.setTotalLength(String.valueOf(totalMinutes)); // Optionally convert to HH:mm:ss format
        moduleRepo.save(module);
    }
}
