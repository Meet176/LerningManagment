package com.mg.serviceImpl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.support.Repositories;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.mg.DTO.RegisterRequestDTO;
import com.mg.entity.Role;
import com.mg.entity.UserEntity;
import com.mg.repository.UserRepository;
import com.mg.service1.UserService;

@Service
public class UserDetailsServiceImpl implements  UserService, UserDetailsService 
{
	@Autowired
	private UserRepository userRepository;
	
	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
	    UserEntity user = userRepository.findByEmail(email);
	    if (user == null) {
	        throw new UsernameNotFoundException("User not found with email: " + email);
	    }

	    return new User(
	        user.getEmail(),
	        user.getPassword(),
	        List.of(new SimpleGrantedAuthority("ROLE_" + user.getRole().name()))
	    );
	}

	@Override
	public UserEntity saveUser(UserEntity user) {
		 return userRepository.save(user);
	}

	@Override
	public Optional<UserEntity> findByEmail(String email) {
		return Optional.of(userRepository.findByEmail(email));
	}

	@Override
	public boolean existsByEmail(String email) 
	{
		 return userRepository.existsByEmail(email);
	}
	
	@Override
    public List<UserEntity> getAllInstructors() {
        return userRepository.findByRole(Role.INSTRUCTOR);
    }
}
