package com.mg.serviceImpl;

import com.mg.DTO.CourseModuleDTO;
import com.mg.DTO.SequenceUpdateRequest;
import com.mg.entity.CourseEntity;
import com.mg.entity.CourseModule;
import com.mg.exception.ResourceNotFoundException;
import com.mg.mapper.CourseModuleMapper;
import com.mg.repository.CourseModuleRepository;
import com.mg.repository.CourseRepository;
import com.mg.service1.CourseModuleService;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;




@Service
public   class CourseModuleServiceImpl implements CourseModuleService 
{
	@Autowired
	private CourseRepository courseRepo;
	
	@Autowired
	private CourseModuleRepository moduleRepo;
	
	@Autowired
	private CourseModuleMapper mapper;
	

	@Override
	public CourseModuleDTO createModule(Long courseId, CourseModuleDTO dto) 
	{
		CourseEntity course = courseRepo.findById(courseId)
	            .orElseThrow(() -> new RuntimeException("Course not found"));

		
        
		return mapper.toDTO(moduleRepo.save(mapper.toEntity(dto, course)));
	}

	@Override
	public List<CourseModule> getModulesByCourseId(Long courseId) 
	{
		
		fixOldTotalLengthFormats();
        return moduleRepo.findByCourseIdAndDeletedDateIsNull(courseId);
		
	}

	@Override
	public CourseModuleDTO updateModule(Long id, CourseModuleDTO dto) 
	{
		CourseModule module = moduleRepo.findById(id)
				.orElseThrow(()-> new ResourceNotFoundException("The Resorce Not Found To Update"));
		
		 module.setTitle(dto.getTitle());
		    module.setContentCount(dto.getContentCount());
		    module.setTotalLength(dto.getTotal_length());
		    module.setIsFree(dto.getIsFree());
		    module.setDetails(dto.getDetails());
		    module.setSerialNumber(dto.getSerialNumber());
		    
		    CourseModule updated = moduleRepo.save(module);
	        return mapper.toDTO(updated);
	}

	@Override
	public void deleteModule(Long id) 
	{
		CourseModule module = moduleRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Module not found"));
        module.setDeletedDate(LocalDateTime.now());
        moduleRepo.save(module);
		
	}

	@Override
	public CourseModuleDTO restoreModule(Long id) 
	{
		  CourseModule module = moduleRepo.findById(id)
	                .orElseThrow(() -> new ResourceNotFoundException("Module not found"));
		  
		 
		  if (module.getDeletedDate() == null)
		  	{
	            throw new RuntimeException("Module is already active");
	        }
		  
		  
	        module.setDeletedDate(null);
	        return mapper.toDTO(moduleRepo.save(module));
	}

	@Override
	public CourseModuleDTO makeModulePaid(Long moduleId) 
	{
		 CourseModule module = moduleRepo.findById(moduleId)
	                .orElseThrow(() -> new RuntimeException("Module not found"));

	        module.setIsFree(false);
	        return mapper.toDTO(moduleRepo.save(module));
	}

	@Override
	public CourseModuleDTO makeModuleFree(Long moduleId) 
	{
		 CourseModule module = moduleRepo.findById(moduleId)
	                .orElseThrow(() -> new RuntimeException("Module not found"));

	        module.setIsFree(true);
	        
	        return mapper.toDTO(moduleRepo.save(module));
	}

	@Override
	public CourseModuleDTO getModuleById(Long id) 
	{
		   CourseModule module = moduleRepo.findById(id)
	                .orElseThrow(() -> new ResourceNotFoundException("Module not found"));
	        return mapper.toDTO(module);
	}

	@Override
	public void fixOldTotalLengthFormats() 
	{
		  List<CourseModule> allModules = moduleRepo.findAll(); // or a custom query for only affected ones

	        for (CourseModule module : allModules) {
	            try 
	            {
	                // Try parsing old numeric value
	                int minutes = Integer.parseInt(module.getTotalLength());
	                module.setTotalLength(formatDuration(minutes));
	                moduleRepo.save(module);
	            }
	            catch (NumberFormatException e) 
	            {
	                // Already formatted (e.g., "1h 45m"), skip
	            }
	        }
		
	}

	private String formatDuration(int totalMinutes) 
	{
		 int hours = totalMinutes / 60;
	        int minutes = totalMinutes % 60;

	        StringBuilder sb = new StringBuilder();
	        if (hours > 0) {
	            sb.append(hours).append("h");
	        }
	        if (minutes > 0 || hours == 0) {
	            if (sb.length() > 0) sb.append(" ");
	            sb.append(minutes).append("m");
	        }

	        return sb.toString();
	}

	@Override
	public void updateSequences(List<SequenceUpdateRequest> modules) 
	{
		for (SequenceUpdateRequest m : modules) {
            CourseModule module = moduleRepo.findById(m.getId())
                    .orElseThrow(() -> new ResourceNotFoundException("Module not found: " + m.getId()));
            module.setSerialNumber(m.getSequence());
            moduleRepo.save(module);
        }
		
	}
	

   
}
