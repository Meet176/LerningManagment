package com.mg.serviceImpl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mg.DTO.CoupenDTO;
import com.mg.entity.Coupen;
import com.mg.exception.ResourceNotFoundException;
import com.mg.mapper.CoupenMapper;
import com.mg.repository.CoupenRepository;
import com.mg.service1.CoupenService;

@Service
public class CoupenServiceImpl implements CoupenService
{
	
	@Autowired
	private CoupenRepository coupenRepos;
	
	@Autowired
	private CoupenMapper mapper;
	
	@Override
	public CoupenDTO createCopuen(CoupenDTO dto) 
	{
		if(coupenRepos.existsByCode(dto.getCode()))
		{
			throw new RuntimeException("Coupen Code Already Exists");
		}
		return mapper.toDto(coupenRepos.save(mapper.toEntity(dto)));
	}

	@Override
	public List<CoupenDTO> getAllCoupen() 
	{
		return coupenRepos.findAll()
				.stream()
				.map(mapper::toDto)
				.collect(Collectors.toList());
	}

	@Override
	public CoupenDTO updateCoupen(Long id, CoupenDTO dto) 
	{
		
		Coupen coupen = coupenRepos.findById(id)
			.orElseThrow(()-> new ResourceNotFoundException("The Data Not Found To Delete...."));
		
		
		
		return mapper.toDto(coupenRepos.save(mapper.toEntity(dto)));
	}

	@Override
	public void deleteCoupen(Long id) 
	{
			coupenRepos.deleteById(id);
	}

}
