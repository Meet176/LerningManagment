package com.mg.serviceImpl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.mg.DTO.SubCategoryDto;
import com.mg.entity.Category;
import com.mg.entity.SubCategory;
import com.mg.repository.CateGoryRepository;
import com.mg.repository.SubCategoryRepository;
import com.mg.service1.SubCategoryService;

@Service
public class SubCategoryServiceImpl implements SubCategoryService {

    @Autowired
    private SubCategoryRepository subCategoryRepo;

    @Autowired
    private CateGoryRepository categoryRepo;

    private static final String IMAGE_UPLOAD_DIR = "uploads/";

    private SubCategory mapToEntity(SubCategoryDto dto, MultipartFile imageFile, Long categoryId) {
        SubCategory subCategory = new SubCategory();
        subCategory.setName(dto.getName());

        if (imageFile != null && !imageFile.isEmpty()) {
            try {
                File dir = new File(IMAGE_UPLOAD_DIR);
                if (!dir.exists()) {
                    dir.mkdirs();
                }

                String originalFilename = imageFile.getOriginalFilename();
                Path filePath = Paths.get(IMAGE_UPLOAD_DIR, originalFilename);
                Files.write(filePath, imageFile.getBytes());

                subCategory.setImage(originalFilename);
            } catch (IOException e) {
                throw new RuntimeException("Image upload failed: " + e.getMessage());
            }
        }

        Category category = categoryRepo.findById(categoryId)
                .orElseThrow(() -> new RuntimeException("Category not found with ID: " + categoryId));

        subCategory.setCategory(category);
        return subCategory;
    }

    @Override
    public SubCategory createSubCategory(SubCategoryDto dto, MultipartFile image, Long categoryId) {
        
    	 if (categoryId == null || !categoryRepo.existsById(categoryId)) {
    	        throw new RuntimeException("Invalid or missing category ID: " + categoryId);
    	    }
    	return subCategoryRepo.save(mapToEntity(dto, image, categoryId));
    }

    @Override
    public List<SubCategory> getAllSubCategories() {
        return subCategoryRepo.findAll();
    }

    @Override
    public SubCategory updateSubCategory(Long id, SubCategoryDto dto, MultipartFile image, Long categoryId) {
        SubCategory subCategory = subCategoryRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("SubCategory not found"));

        subCategory.setName(dto.getName());

        if (image != null && !image.isEmpty()) {
            try {
                File dir = new File(IMAGE_UPLOAD_DIR);
                if (!dir.exists()) {
                    dir.mkdirs();
                }

                String originalFilename = image.getOriginalFilename();
                Path filePath = Paths.get(IMAGE_UPLOAD_DIR, originalFilename);
                Files.write(filePath, image.getBytes());

                subCategory.setImage(originalFilename);
            } catch (IOException e) {
                throw new RuntimeException("Image upload failed: " + e.getMessage());
            }
        }

        if (categoryId != null) {
            Category category = categoryRepo.findById(categoryId)
                    .orElseThrow(() -> new RuntimeException("Category not found with ID: " + categoryId));
            subCategory.setCategory(category);
        }

        return subCategoryRepo.save(subCategory);
    }

    @Override
    public void deleteSubCategory(Long id) {
        SubCategory subCategory = subCategoryRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("SubCategory not found"));

        subCategory.setDeletedDate(LocalDateTime.now());
        subCategoryRepo.save(subCategory);
    }

    @Override
    public SubCategory restoreSubCategory(Long id) {
        SubCategory subCategory = subCategoryRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("SubCategory not found"));

        if (subCategory.getDeletedDate() == null) {
            throw new RuntimeException("SubCategory is already active");
        }

        subCategory.setDeletedDate(null);
        return subCategoryRepo.save(subCategory);
    }

    @Override
    public SubCategory activateSubCategory(Long id) {
        SubCategory subCategory = subCategoryRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("SubCategory not found"));

        subCategory.setActive(true);
        return subCategoryRepo.save(subCategory);
    }

    @Override
    public SubCategory deactivateSubCategory(Long id) {
        SubCategory subCategory = subCategoryRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("SubCategory not found"));

        subCategory.setActive(false);
        return subCategoryRepo.save(subCategory);
    }

    @Override
    public Page<SubCategory> searchSubCategories(String name, String filter, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("id").descending());

        switch (filter.toLowerCase()) {
            case "active":
                return subCategoryRepo.findByDeletedDateIsNullAndNameContainingIgnoreCase(name, pageable);
            case "deleted":
                return subCategoryRepo.findByDeletedDateIsNotNullAndNameContainingIgnoreCase(name, pageable);
            default:
                return subCategoryRepo.findByNameContainingIgnoreCase(name, pageable);
        }
    }

    @Override
    public Page<SubCategory> getPagedSubCategories(int page, int size, String filter) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("id").descending());

        switch (filter.toLowerCase()) {
            case "active":
                return subCategoryRepo.findByDeletedDateIsNull(pageable);
            case "deleted":
                return subCategoryRepo.findByDeletedDateIsNotNull(pageable);
            default:
                return subCategoryRepo.findAll(pageable);
        }
    }

    @Override
    public SubCategory getSubCategoryById(Long id) {
        return subCategoryRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("SubCategory not found"));
    }

    @Override
    public List<SubCategory> findByDeletedFalse() {
        return subCategoryRepo.findByDeletedDateIsNull();
    }
}
