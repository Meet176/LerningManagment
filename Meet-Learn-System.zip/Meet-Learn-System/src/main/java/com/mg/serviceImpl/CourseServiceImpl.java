package com.mg.serviceImpl;

import com.mg.DTO.CourseDTO;
import com.mg.admin.contorller.CategoryController;
import com.mg.entity.CourseEntity;
import com.mg.entity.SubCategory;
import com.mg.repository.CourseRepository;
import com.mg.repository.SubCategoryRepository;
import com.mg.service1.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class CourseServiceImpl implements CourseService {

    private final CategoryController categoryController;

    @Autowired
    private CourseRepository courseRepo;

    @Autowired
    private SubCategoryRepository subCategoryRepo;

    private static final String IMAGE_UPLOAD_DIR = "uploads/";

    CourseServiceImpl(CategoryController categoryController) {
        this.categoryController = categoryController;
    }

    private CourseEntity mapToEntity(CourseDTO dto) {
        CourseEntity course = new CourseEntity();
        SubCategory subCategory = subCategoryRepo.findById(dto.getSubCategoryId())
                .orElseThrow(() -> new RuntimeException("SubCategory not found"));

        course.setSubCategory(subCategory);
        course.setInstructor(dto.getInstructor());
        course.setTitle(dto.getTitle());
        course.setDescription(dto.getDescription());
        course.setMrp(dto.getMrp());
        course.setDiscount(dto.getDiscount());
        course.setPrice(dto.getPrice());
        course.setFree(dto.isFree());
        course.setStatus(dto.getStatus());
        course.setIsActive(true);

        handleThumbnailUpload(course, dto.getThumbnail());

        return course;
    }

    private BigDecimal calculatePrice(BigDecimal mrp, BigDecimal discount, Boolean isFree) {
        if (isFree != null && isFree) return BigDecimal.ZERO;
        if (mrp == null) mrp = BigDecimal.ZERO;
        if (discount == null) discount = BigDecimal.ZERO;
        return mrp.subtract(discount).max(BigDecimal.ZERO);
    }
    
    private void handleThumbnailUpload(CourseEntity course, MultipartFile thumbnail) {
        if (thumbnail != null && !thumbnail.isEmpty()) {
            try {
                File dir = new File(IMAGE_UPLOAD_DIR);
                if (!dir.exists()) dir.mkdirs();

                String filename = System.currentTimeMillis() + "_" + thumbnail.getOriginalFilename();
                Path path = Paths.get(IMAGE_UPLOAD_DIR, filename);
                Files.write(path, thumbnail.getBytes());
                course.setThumbnail(filename);
            } catch (IOException e) {
                throw new RuntimeException("Thumbnail upload failed: " + e.getMessage());
            }
        }
    }

    @Override
    public CourseEntity createCourse(CourseDTO dto) {
        return courseRepo.save(mapToEntity(dto));
    }

    @Override
    public CourseEntity updateCourse(Long id, CourseDTO dto) {
        CourseEntity course = courseRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Course not found"));

        course.setTitle(dto.getTitle());
        course.setDescription(dto.getDescription());
        course.setMrp(dto.getMrp());
        course.setDiscount(dto.getDiscount());
        course.setPrice(dto.getPrice());
        course.setFree(dto.isFree());
        course.setStatus(dto.getStatus());

        if (dto.getSubCategoryId() != null) {
            SubCategory subCategory = subCategoryRepo.findById(dto.getSubCategoryId())
                    .orElseThrow(() -> new RuntimeException("SubCategory not found"));
            course.setSubCategory(subCategory);
        }

        handleThumbnailUpload(course, dto.getThumbnail());

        return courseRepo.save(course);
    }

    @Override
    public void deleteCourse(Long id) {
        CourseEntity course = courseRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Course not found"));
        course.setDeletedDate(LocalDateTime.now());
        courseRepo.save(course);
    }

    @Override
    public CourseEntity restoreCourse(Long id) {
        CourseEntity course = courseRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Course not found"));
        course.setDeletedDate(null);
        return courseRepo.save(course);
    }

    @Override
    public CourseEntity activateCourse(Long id) {
        CourseEntity course = courseRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Course not found"));
        course.setIsActive(true);
        return courseRepo.save(course);
    }

    @Override
    public CourseEntity deactivateCourse(Long id) {
        CourseEntity course = courseRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Course not found"));
        course.setIsActive(false);
        return courseRepo.save(course);
    }

    @Override
    public CourseEntity getCourseById(Long id) {
        return courseRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Course not found"));
    }

    @Override
    public List<CourseEntity> getAllCourses() {
        return courseRepo.findAll();
    }

    @Override
    public Page<CourseEntity> getPagedCourses(int page, int size, String filter) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("id").descending());

        return switch (filter.toLowerCase()) {
            case "active" -> courseRepo.findByDeletedDateIsNull(pageable);
            case "deleted" -> courseRepo.findByDeletedDateIsNotNull(pageable);
            default -> courseRepo.findAll(pageable);
        };
    }

	@Override
	public CourseEntity makeCourseFree(Long id) {
		CourseEntity course = courseRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Course not found with ID: " + id));
        course.setFree(true);
        course.setPrice(BigDecimal.ZERO);
        course.setCreatedAt(LocalDateTime.now());
        return courseRepo.save(course);
	}

	@Override
	public CourseEntity makeCoursePaid(Long id) {
		CourseEntity course = courseRepo.findById(id)
	                .orElseThrow(() -> new RuntimeException("Course not found with ID: " + id));
	        course.setFree(false);
	        course.setPrice(calculatePrice(course.getMrp(), course.getDiscount(), false));
	        course.setCreatedAt(LocalDateTime.now());
	        return courseRepo.save(course);
	}
} 
