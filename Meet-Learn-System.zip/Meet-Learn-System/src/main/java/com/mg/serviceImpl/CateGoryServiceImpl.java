package com.mg.serviceImpl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.mg.DTO.CategoryDto;
import com.mg.entity.Category;
import com.mg.repository.CateGoryRepository;
import com.mg.service1.CategoryService;

@Service
public class CateGoryServiceImpl implements CategoryService {

    @Autowired
    private CateGoryRepository categoryRepo;

    private static final String IMAGE_UPLOAD_DIR = "uploads/";


    private Category mapToEntity(CategoryDto dto) {
        Category category = new Category();
        category.setName(dto.getName());

        MultipartFile imageFile = dto.getImage();
        if (imageFile != null && !imageFile.isEmpty()) {
            try {
                File dir = new File(IMAGE_UPLOAD_DIR);
                if (!dir.exists()) {
                    dir.mkdirs();
                }

                String originalFilename = imageFile.getOriginalFilename();
                Path filePath = Paths.get(IMAGE_UPLOAD_DIR, originalFilename);
                Files.write(filePath, imageFile.getBytes());

                category.setImage(originalFilename);
            } catch (IOException e) {
                throw new RuntimeException("Image upload failed: " + e.getMessage());
            }
        }

        return category;
    }

    @Override
    public Category createCategory(CategoryDto dto) {
        if (categoryRepo.existsByName(dto.getName())) {
            throw new RuntimeException("Category already exists");
        }
        return categoryRepo.save(mapToEntity(dto));
    }

    @Override
    public List<Category> getAllCategories() {
        return categoryRepo.findAll();
    }

    @Override
    public Category updateCategory(Long id, CategoryDto dto) {
        Category category = categoryRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Category not found"));

        category.setName(dto.getName());

        MultipartFile imageFile = dto.getImage();
        if (imageFile != null && !imageFile.isEmpty()) {
            try {
                File dir = new File(IMAGE_UPLOAD_DIR);
                if (!dir.exists()) {
                    dir.mkdirs();
                }

                String originalFilename = imageFile.getOriginalFilename();
                Path filePath = Paths.get(IMAGE_UPLOAD_DIR, originalFilename);
                Files.write(filePath, imageFile.getBytes());

                category.setImage(originalFilename);
            } 
            catch (IOException e) 
            {
                throw new RuntimeException("Image update failed: " + e.getMessage());
            }
        }

        return categoryRepo.save(category);
    }
    @Override
    public Page<Category> getPagedCategories(int page, int size, String filter) 
    {
        Pageable pageable = PageRequest.of(page, size, Sort.by("id").descending());

        switch (filter.toLowerCase()) {
            case "active":
                return categoryRepo.findByDeletedDateIsNull(pageable);
            case "deleted":
                return categoryRepo.findByDeletedDateIsNotNull(pageable);
            default:
                return categoryRepo.findAll(pageable);
        }
    }


    @Override
    public void deleteCategory(Long id) 
    {
        Category category = categoryRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Category not found"));

        category.setDeletedDate(LocalDateTime.now());
        categoryRepo.save(category);
    }

    @Override
    public Category restoreCategory(Long id) 
    {
        Category category = categoryRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Category not found"));

        if (category.getDeletedDate() == null) 
        {
            throw new RuntimeException("Category is already active");
        }

        category.setDeletedDate(null);
        return categoryRepo.save(category);
    }
    
    @Override
    public Category activateCategory(Long id) 
    {
        Category category = categoryRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Category not found"));
        category.setActive(true);
        return categoryRepo.save(category);
    }

    @Override
    public Category deactivateCategory(Long id)
    {
        Category category = categoryRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Category not found"));
        category.setActive(false);
        return categoryRepo.save(category);
    }
    
    @Override
    public Page<Category> searchCategories(String name, String filter, int page, int size) 
    {
        Pageable pageable = PageRequest.of(page, size, Sort.by("id").descending());
        switch (filter) {
          case "active":
            return categoryRepo.findByDeletedDateIsNullAndNameContainingIgnoreCase(name, pageable);
          case "deleted":
            return categoryRepo.findByDeletedDateIsNotNullAndNameContainingIgnoreCase(name, pageable);
          default:
            return categoryRepo.findByNameContainingIgnoreCase(name, pageable);
        }
    }



    @Override
    public List<Category> findByDeletedFalse() {
        return categoryRepo.findByDeletedDateIsNull(); // This method must exist in your repository
    }
}