package com.mg.entity;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.apache.catalina.User;
import org.hibernate.annotations.Where;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Where(clause = "deleted_date IS NULL")
public class Enrollment extends BaseEntity 
{
	
	private LocalDate enrollment;
	private Boolean isCompleted;
	
	private BigDecimal price;
	private BigDecimal discount;
	private BigDecimal mrp;
	
	
	private String paymentMethod;
	
	@ManyToOne
	@JoinColumn(name="user_id")
	private UserEntity student;
	
	@ManyToOne
	@JoinColumn(name="course_id")
	private CourseEntity  course;
	
	@Column(name="applied_coupon")
	private String applicationCoupone;
}
