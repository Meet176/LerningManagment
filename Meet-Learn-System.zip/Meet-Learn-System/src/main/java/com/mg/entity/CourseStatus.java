package com.mg.entity;

public enum CourseStatus 
{
    DRAFT,
    PUBLISHED
}
