package com.mg.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.Where;
import org.springframework.web.multipart.MultipartFile;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "course_content")
@Data
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Where(clause = "deleted_at IS NULL")
public class CourseContent extends BaseEntity
{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(length = 255)
	private String title;
	
	
	private Integer sequence;
	
	private Boolean IsFree;
	
	private String fileType;
	
	
	 private Integer durationMinutes; // Duration in minutes

     private String filePath; // To store file name or path
	
     @ManyToOne
     @JoinColumn(name = "module_id", nullable = false)
     private CourseModule courseModule;
	
	 
	   
	@Column(name = "deleted_date")
	private LocalDateTime deletedDate;

	public void setFilePath(String filename) {
		// TODO Auto-generated method stub
		
	}

}
