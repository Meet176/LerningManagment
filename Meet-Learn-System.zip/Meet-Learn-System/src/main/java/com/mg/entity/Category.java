package com.mg.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "category")
public class Category extends BaseEntity
{
	
	@Column(nullable = true)
	private String name;
	private String image;
	private boolean active = true; 

	

}