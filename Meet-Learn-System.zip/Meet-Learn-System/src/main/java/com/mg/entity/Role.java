package com.mg.entity;

public  enum Role {
	ADMIN,
	INSTRUCTOR,
	STUDENT
}
