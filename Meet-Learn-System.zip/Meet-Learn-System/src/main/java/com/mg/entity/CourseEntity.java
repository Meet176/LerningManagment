package com.mg.entity;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CourseEntity extends BaseEntity
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "sub_category_id")
    private SubCategory subCategory;

    private Long instructor; // user_id

   
    private String title;
    private String description;
    private BigDecimal mrp;
    private BigDecimal discount;
    private BigDecimal price;
    private String thumbnail;
    private boolean isFree;

    @Enumerated(EnumType.STRING)
    private CourseStatus status;

    private Boolean isActive = true;
    private LocalDateTime deletedDate;
}
