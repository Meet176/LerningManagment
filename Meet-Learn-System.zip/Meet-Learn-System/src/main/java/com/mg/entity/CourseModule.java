package com.mg.entity;


import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "course_module")
public class CourseModule extends BaseEntity {

    @ManyToOne
    @JoinColumn(name = "course_id", nullable = false)
    @JsonIgnore
    private CourseEntity course;

    private String title;
   
    private String totalLength; // You can change to `Duration` or `int` (minutes) if needed

    private String details;


    @Column(name = "serial_number")
    private int serialNumber;


    
    private  Boolean isFree = true;
    

    @Column(name = "content_count")
    private Integer contentCount;	

}
