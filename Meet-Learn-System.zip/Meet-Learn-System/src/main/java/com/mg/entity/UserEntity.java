package com.mg.entity;

import org.hibernate.annotations.Where;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "users") // Optional but recommended to avoid default naming issues
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true) // Since it extends BaseEntity
@Where(clause = "deleted_at IS NULL")
public class UserEntity extends BaseEntity {

    @Column(unique = true, length = 130,nullable = false)
    private String email;

    @Column(nullable = false)
    private String password;

    @Enumerated(EnumType.STRING)
    @Column(length = 30, nullable = false)
    private Role role;

    @Column(length = 200)
    private String fullname;

    @Column(length = 20)
    private String phone;

    @Enumerated(EnumType.STRING)
    @Column(length = 50)
    private Status status;

    @Column(length = 255)
    private String imag;
    
    
}
