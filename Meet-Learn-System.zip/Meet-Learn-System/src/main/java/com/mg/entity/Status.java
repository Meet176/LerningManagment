package com.mg.entity;

public enum Status 
{
	Active,Inactive
}
