package com.mg.repository;

import com.mg.entity.CourseModule;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface CourseModuleRepository extends JpaRepository<CourseModule, Long>,JpaSpecificationExecutor<CourseModule>
{
	List<CourseModule> findByCourseIdAndDeletedDateIsNull(Long courseId);

	
	int countByCourseIdAndDeletedDateIsNull(Long courseId);
	
	@Query("SELECT MAX(m.serialNumber) FROM CourseModule m WHERE m.course.id = :courseId AND m.deletedDate IS NULL")
	Optional<Integer> findMaxSerialNumberByCourseId(@Param("courseId") Long courseId);
}
