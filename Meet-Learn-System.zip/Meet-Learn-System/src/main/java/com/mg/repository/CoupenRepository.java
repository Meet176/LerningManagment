package com.mg.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mg.entity.Coupen;

public interface CoupenRepository extends JpaRepository<Coupen,Long>
{
	 boolean existsByCode(String code);

	Optional<Coupen> findByCode(String code);
}
