package com.mg.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;


import com.mg.entity.SubCategory;

public interface SubCategoryRepository extends JpaRepository<SubCategory,Long>
{
	boolean existsByName(String name);
	
	
	List<SubCategory> findByDeletedDateIsNull();
	 Page<SubCategory> findByDeletedDateIsNull(Pageable pageable);

	 Page<SubCategory> findByDeletedDateIsNotNull(Pageable pageable);

	 Page<SubCategory> findByNameContainingIgnoreCase(String name, Pageable pageable);
	    Page<SubCategory> findByDeletedDateIsNullAndNameContainingIgnoreCase(String name, Pageable pageable);
	    Page<SubCategory> findByDeletedDateIsNotNullAndNameContainingIgnoreCase(String name, Pageable pageable);
}
