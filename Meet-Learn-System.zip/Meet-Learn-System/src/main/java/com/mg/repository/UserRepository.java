package com.mg.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mg.entity.Role;
import com.mg.entity.UserEntity;



public interface UserRepository extends JpaRepository<UserEntity,Long>
{
	UserEntity findByEmail(String email);
	boolean existsByEmail(String email);
	List<UserEntity> findByRole(Role role);
}
