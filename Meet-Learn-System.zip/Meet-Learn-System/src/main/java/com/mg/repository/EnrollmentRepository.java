package com.mg.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mg.entity.Enrollment;


public interface EnrollmentRepository extends JpaRepository<Enrollment,Long>
{
	  List<Enrollment> findByDeletedDateIsNull();
	  List<Enrollment> findByStudentIdAndDeletedDateIsNull(Long studentId);
}
