package com.mg.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mg.entity.CourseContent;

public interface CourseContentRepository extends JpaRepository<CourseContent, Long> {

    List<CourseContent> findByCourseModule_IdAndDeletedDateIsNull(Long moduleId); // ✅ Corrected field path

    List<CourseContent> findByCourseModuleId(Long moduleId); // ✅ Also update this
}
