package com.mg.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mg.entity.Notification;

public interface NotificationRepository extends JpaRepository<Notification,Long>
{
	List<Notification> findByUserIdOrderByCreatedDateDesc(Long recipientId);
}
