package com.mg.repository;

import com.mg.entity.CourseEntity;
import com.mg.entity.CourseModule;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CourseRepository extends JpaRepository<CourseEntity, Long> 
{
	Page<CourseEntity> findByDeletedDateIsNull(Pageable pageable);
    Page<CourseEntity> findByDeletedDateIsNotNull(Pageable pageable);

}