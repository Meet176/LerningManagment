package com.mg.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mg.entity.Category;



public interface CateGoryRepository extends JpaRepository<Category, Long>{

	 boolean existsByName(String name);
	 List<Category> findByDeletedDateIsNull();
	 Page<Category> findByDeletedDateIsNull(Pageable pageable);

	 Page<Category> findByDeletedDateIsNotNull(Pageable pageable);

	 Page<Category> findByNameContainingIgnoreCase(String name, Pageable pageable);
	    Page<Category> findByDeletedDateIsNullAndNameContainingIgnoreCase(String name, Pageable pageable);
	    Page<Category> findByDeletedDateIsNotNullAndNameContainingIgnoreCase(String name, Pageable pageable);
	
}