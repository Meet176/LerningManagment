package com.mg.service1;

import java.util.List;
import java.util.Optional;

import com.mg.DTO.RegisterRequestDTO;
import com.mg.entity.UserEntity;

public interface UserService 
{
	UserEntity saveUser(UserEntity user);
    Optional<UserEntity> findByEmail(String email);
    boolean existsByEmail(String email);
    List<UserEntity> getAllInstructors();
}
