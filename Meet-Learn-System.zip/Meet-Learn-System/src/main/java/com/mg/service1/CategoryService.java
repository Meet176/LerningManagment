package com.mg.service1;

import org.springframework.data.domain.Page;



import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.mg.DTO.CategoryDto;
import com.mg.entity.Category;
public interface CategoryService 
{
    Category createCategory(CategoryDto categoryDTO);
    List<Category> getAllCategories();
    Category updateCategory(Long id, CategoryDto categoryDTO);
    void deleteCategory(Long id);
    Category restoreCategory(Long id);
    List<Category> findByDeletedFalse(); // Return only non-deleted categories
	Category deactivateCategory(Long id);
	Category activateCategory(Long id);
	Page<Category> searchCategories(String name, String filter, int page, int size);
	Page<Category> getPagedCategories(int page, int size, String filter);
	
}
