package com.mg.service1;

import com.mg.DTO.CourseModuleDTO;
import com.mg.DTO.SequenceUpdateRequest;
import com.mg.entity.CourseModule;

import java.util.List;

public interface CourseModuleService 
{
	 CourseModuleDTO createModule(Long courseId, CourseModuleDTO dto);
	    List<CourseModule> getModulesByCourseId(Long courseId);
	    CourseModuleDTO updateModule(Long id, CourseModuleDTO dto);
	    void deleteModule(Long id);
	    CourseModuleDTO restoreModule(Long id);
	    CourseModuleDTO makeModulePaid(Long moduleId);
	    CourseModuleDTO makeModuleFree(Long moduleId);
	    CourseModuleDTO getModuleById(Long id);
	    void fixOldTotalLengthFormats();
	    void updateSequences(List<SequenceUpdateRequest> modules);
}
