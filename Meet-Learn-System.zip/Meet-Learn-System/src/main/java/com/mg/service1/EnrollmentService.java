package com.mg.service1;

import java.util.List;

import com.mg.DTO.EnrollmentDTO;
import com.mg.entity.Enrollment;

public interface EnrollmentService 
{

    List<EnrollmentDTO> getAllEnrollment();
    List<EnrollmentDTO>getActiveEnrollment();
    EnrollmentDTO createEnrollment(EnrollmentDTO dto);
    EnrollmentDTO updateEnrollment(Long id, EnrollmentDTO dto);
    void deleteEnrollment(Long id);
    Enrollment restoreEnrollment(Long id);
}
