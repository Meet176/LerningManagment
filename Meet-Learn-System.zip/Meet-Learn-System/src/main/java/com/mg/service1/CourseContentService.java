package com.mg.service1;

import java.util.List;

import com.mg.DTO.CourseContentDTO;
import com.mg.DTO.SequenceUpdateRequest;

import io.jsonwebtoken.io.IOException;

public interface CourseContentService 
{
	  	CourseContentDTO createContent(CourseContentDTO dto) throws IOException, java.io.IOException;
	    List<CourseContentDTO> getByModuleId(Long moduleId);
	    CourseContentDTO updateContent(Long id, CourseContentDTO dto) throws IOException, java.io.IOException;
	    void softDelete(Long id);
	    CourseContentDTO restore(Long id);
		void Delete(Long id);
		void updateSequence(Long id, Integer sequence);
		
		void updateSequence(List<SequenceUpdateRequest> requestList);
}
