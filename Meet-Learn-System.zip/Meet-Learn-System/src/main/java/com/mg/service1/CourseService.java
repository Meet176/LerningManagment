package com.mg.service1;

import com.mg.DTO.CourseDTO;
import com.mg.entity.CourseEntity;
import org.springframework.data.domain.Page;
import java.util.List;

public interface CourseService {
    CourseEntity createCourse(CourseDTO dto);
    CourseEntity updateCourse(Long id, CourseDTO dto);
    void deleteCourse(Long id);
    CourseEntity restoreCourse(Long id);
    CourseEntity activateCourse(Long id);
    CourseEntity deactivateCourse(Long id);
    CourseEntity getCourseById(Long id);
    List<CourseEntity> getAllCourses();
    Page<CourseEntity> getPagedCourses(int page, int size, String filter);
    CourseEntity makeCourseFree(Long id);
    CourseEntity makeCoursePaid(Long id);

}