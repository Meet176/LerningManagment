package com.mg.service1;

import java.util.List;

import com.mg.DTO.CoupenDTO;

public interface CoupenService 
{
	CoupenDTO createCopuen(CoupenDTO dto);
	List<CoupenDTO> getAllCoupen();
	CoupenDTO updateCoupen(Long id,CoupenDTO dto);
	void deleteCoupen(Long id);
}
