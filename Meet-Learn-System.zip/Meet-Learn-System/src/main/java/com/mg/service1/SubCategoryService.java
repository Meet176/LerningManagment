package com.mg.service1;

import org.springframework.data.domain.Page;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

import com.mg.DTO.SubCategoryDto;
import com.mg.entity.SubCategory;

public interface SubCategoryService {

    SubCategory createSubCategory(SubCategoryDto dto, MultipartFile image, Long categoryId);

    List<SubCategory> getAllSubCategories();

    SubCategory updateSubCategory(Long id, SubCategoryDto dto, MultipartFile image, Long categoryId);

    void deleteSubCategory(Long id);

    SubCategory restoreSubCategory(Long id);

    List<SubCategory> findByDeletedFalse(); // Return only non-deleted subcategories

    SubCategory deactivateSubCategory(Long id);

    SubCategory activateSubCategory(Long id);

    Page<SubCategory> searchSubCategories(String name, String filter, int page, int size);

    Page<SubCategory> getPagedSubCategories(int page, int size, String filter);

    SubCategory getSubCategoryById(Long id);
}
