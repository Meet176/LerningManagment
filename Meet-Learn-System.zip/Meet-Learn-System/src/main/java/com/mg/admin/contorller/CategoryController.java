package com.mg.admin.contorller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.mg.DTO.CategoryDto;
import com.mg.entity.Category;
import com.mg.service1.CategoryService;



@RestController
@RequestMapping("/api/v1/admin/category")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    // ✅ Create Category with image upload
    @PostMapping
    public ResponseEntity<Category> create(
            @RequestParam("name") String name,
            @RequestParam("image") MultipartFile image) {

        CategoryDto dto = new CategoryDto();
        dto.setName(name);
        dto.setImage(image);

        return ResponseEntity.ok(categoryService.createCategory(dto));
    }

    // ✅ Get all categories (active + deleted)
    @GetMapping
    public ResponseEntity<List<Category>> getAll() {
        return ResponseEntity.ok(categoryService.getAllCategories());
    }

    // ✅ Get only active categories
    @GetMapping("/active")
    public ResponseEntity<List<Category>> getActiveCategories() {
        return ResponseEntity.ok(categoryService.findByDeletedFalse());
    }

    // ✅ Update category (name & image)
    @PutMapping("/{id}")
    public ResponseEntity<Category> update(
            @PathVariable Long id,
            @RequestParam("name") String name,
            @RequestParam(value = "image", required = false) MultipartFile image) {

        CategoryDto dto = new CategoryDto();
        dto.setName(name);
        dto.setImage(image);

        return ResponseEntity.ok(categoryService.updateCategory(id, dto));
    }

    // ✅ Soft delete category
    @DeleteMapping("/{id}")
    public ResponseEntity<String> delete(@PathVariable Long id) 
    {
        categoryService.deleteCategory(id);
        return ResponseEntity.ok("Category soft-deleted");
    }
 // ✅ Deactivate category
    @PutMapping("/deactivate/{id}")
    public ResponseEntity<Category> deactivate(@PathVariable Long id) 
    {
        return ResponseEntity.ok(categoryService.deactivateCategory(id));
    }

    // ✅ Activate category
    @PutMapping("/activate/{id}")
    public ResponseEntity<Category> activate(@PathVariable Long id)
    {
        return ResponseEntity.ok(categoryService.activateCategory(id));
    }
    @GetMapping("/paged")
    public ResponseEntity<Page<Category>> getPagedCategories(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "all") String filter // "active", "deleted", "all"
    ) 
    {
        return ResponseEntity.ok(categoryService.getPagedCategories(page, size, filter));
    }

    @GetMapping("/search")
    public ResponseEntity<Page<Category>> search(
        @RequestParam(defaultValue = "") String name,
        @RequestParam(defaultValue = "all") String filter,
        @RequestParam(defaultValue = "0") int page,
        @RequestParam(defaultValue = "10") int size
    ) 
    {
        return ResponseEntity.ok(categoryService.searchCategories(name, filter, page, size));
    }

   


    // ✅ Restore category
    @PutMapping("/restore/{id}")
    public ResponseEntity<Category> restore(@PathVariable Long id) 
    {
        return ResponseEntity.ok(categoryService.restoreCategory(id));
    }
}