package com.mg.admin.contorller;

import com.mg.DTO.CourseContentDTO;
import com.mg.DTO.SequenceUpdateRequest;
import com.mg.service1.CourseContentService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/v1/admin/course-content")
public class CourseContentController {

    @Autowired
    private CourseContentService courseContentService;

    // ✅ Create Content
    @PostMapping("/create")
    public ResponseEntity<?> createContent(@ModelAttribute CourseContentDTO dto) throws IOException 
    {
        return ResponseEntity.ok(courseContentService.createContent(dto));
    }

    // ✅ Get All Contents for Module
    @GetMapping("/by-module/{moduleId}")
    public ResponseEntity<?> getByModuleId(@PathVariable Long moduleId) {
        return ResponseEntity.ok(courseContentService.getByModuleId(moduleId));
    }

    // ✅ Update Content
    @PutMapping("/update/{id}")
    public ResponseEntity<?> updateContent(@PathVariable Long id, @ModelAttribute CourseContentDTO dto) throws IOException {
        return ResponseEntity.ok(courseContentService.updateContent(id, dto));
    }

    // ✅ Soft Delete Content
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> softDelete(@PathVariable Long id) {
        courseContentService.softDelete(id);
        return ResponseEntity.ok("Content soft deleted successfully");
    }

    // ✅ Hard Delete Content (Optional)
    @DeleteMapping("/hard-delete/{id}")
    public ResponseEntity<?> hardDelete(@PathVariable Long id) {
        courseContentService.Delete(id);
        return ResponseEntity.ok("Content hard deleted successfully");
    }

    // ✅ Restore Soft Deleted Content
    @PutMapping("/restore/{id}")
    public ResponseEntity<?> restore(@PathVariable Long id) {
        return ResponseEntity.ok(courseContentService.restore(id));
    }

    // ✅ Update a single content sequence
    @PutMapping("/update-sequence/{id}")
    public ResponseEntity<?> updateSequenceById(@PathVariable Long id, @RequestParam Integer sequence) {
        courseContentService.updateSequence(id, sequence);
        return ResponseEntity.ok("Sequence updated successfully");
    }

    // ✅ Update bulk sequence
    @PutMapping("/update-sequence")
    public ResponseEntity<?> updateSequence(@RequestBody List<SequenceUpdateRequest> requestList) {
        courseContentService.updateSequence(requestList);
        return ResponseEntity.ok("Sequence list updated successfully");
    }
}
