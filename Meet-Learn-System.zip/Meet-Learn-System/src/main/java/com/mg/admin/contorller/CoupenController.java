package com.mg.admin.contorller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mg.DTO.CoupenDTO;
import com.mg.service1.CoupenService;

@RestController
@RequestMapping("/api/admin/coupons")
public class CoupenController 
{
	   @Autowired
	    private CoupenService couponService;

	    @PostMapping
	    public ResponseEntity<CoupenDTO> create(@RequestBody CoupenDTO dto) {
	        return ResponseEntity.ok(couponService.createCopuen(dto));
	    }

	    @GetMapping
	    public ResponseEntity<List<CoupenDTO>> getAll() {
	        return ResponseEntity.ok(couponService.getAllCoupen());
	    }

	    @PutMapping("/{id}")
	    public ResponseEntity<CoupenDTO> update(@PathVariable Long id, @RequestBody CoupenDTO dto) {
	        return ResponseEntity.ok(couponService.updateCoupen(id, dto));
	    }

	    @DeleteMapping("/{id}")
	    public ResponseEntity<String> delete(@PathVariable Long id) 
	    {
	        couponService.deleteCoupen(id);
	        return ResponseEntity.ok("Coupon deleted");
	    }
	
}
