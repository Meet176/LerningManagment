package com.mg.admin.contorller;

import com.mg.DTO.CourseModuleDTO;
import com.mg.DTO.SequenceUpdateRequest;
import com.mg.service1.CourseModuleService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/admin/module")
@RequiredArgsConstructor
public class CourseModuleController {

    private final CourseModuleService service;

    @PostMapping("/{courseId}")
    public CourseModuleDTO createModule(@PathVariable Long courseId, @RequestBody CourseModuleDTO dto) {
        return service.createModule(courseId, dto);
    }

//    @GetMapping("/course/{courseId}")
//    public List<CourseModuleDTO> getModulesByCourseId(@PathVariable Long courseId) {
//        return service.getModulesByCourseId(courseId);
//    }

    @PutMapping("/{id}")
    public CourseModuleDTO updateModule(@PathVariable Long id, @RequestBody CourseModuleDTO dto) {
        return service.updateModule(id, dto);
    }

    @DeleteMapping("/{id}")
    public void deleteModule(@PathVariable Long id) {
        service.deleteModule(id);
    }

    @PutMapping("/restore/{id}")
    public CourseModuleDTO restoreModule(@PathVariable Long id) {
        return service.restoreModule(id);
    }

    @PutMapping("/paid/{id}")
    public CourseModuleDTO makePaid(@PathVariable Long id) {
        return service.makeModulePaid(id);
    }

    @PutMapping("/free/{id}")
    public CourseModuleDTO makeFree(@PathVariable Long id) {
        return service.makeModuleFree(id);
    }

    @GetMapping("/{id}")
    public CourseModuleDTO getById(@PathVariable Long id) {
        return service.getModuleById(id);
    }

    @PutMapping("/fix-lengths")
    public void fixLengths() {
        service.fixOldTotalLengthFormats();
    }

    @PutMapping("/update-sequence")
    public void updateSequences(@RequestBody List<SequenceUpdateRequest> list) {
        service.updateSequences(list);
    }
}
