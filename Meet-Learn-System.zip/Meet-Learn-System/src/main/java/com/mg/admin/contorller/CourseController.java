package com.mg.admin.contorller;

import com.mg.DTO.CourseDTO;
import com.mg.controller.AdminController;
import com.mg.entity.CourseEntity;
import com.mg.entity.CourseStatus;
import com.mg.entity.SubCategory;
import com.mg.repository.CourseRepository;
import com.mg.repository.SubCategoryRepository;
import com.mg.service1.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.CrudRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.multipart.MultipartException;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/admin/course")
public class CourseController {

    private final AdminController adminController;

    @Autowired
    private CourseService courseService;
    
    @Autowired
    private CourseRepository courseRepository;
    
    @Autowired
    private SubCategoryRepository subCategoryRepository;

    CourseController(AdminController adminController) {
        this.adminController = adminController;
    }

    // ✅ Create Course
    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> createCourse(
            @RequestParam("subCategoryId") Long subCategoryId,
            @RequestParam("instructor") Long instructor,
            @RequestParam("title") String title,
            @RequestParam("description") String description,
            @RequestParam("mrp") BigDecimal mrp,
            @RequestParam("discount") BigDecimal discount,
            @RequestParam("price") BigDecimal price,
            @RequestParam("isFree") boolean isFree,
            @RequestParam("status") CourseStatus status,
            @RequestParam("thumbnail") MultipartFile thumbnail
    ) 
    {
        SubCategory subCategory = subCategoryRepository.findById(subCategoryId)
            .orElseThrow(() -> new RuntimeException("SubCategory not found"));

        // Optional: Save file to /uploads and get URL
        String fileName = System.currentTimeMillis() + "_" + thumbnail.getOriginalFilename();
        Path path = Paths.get("uploads").resolve(fileName);
        try {
            Files.copy(thumbnail.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Image upload failed");
        }

        CourseEntity course = new CourseEntity();
        course.setSubCategory(subCategory);
        course.setInstructor(instructor);
        course.setTitle(title);
        course.setDescription(description);
        course.setMrp(mrp);
        course.setDiscount(discount);
        course.setPrice(price);;
        course.setFree(isFree);
        course.setStatus(status);
        course.setThumbnail("/uploads/" + fileName);

        courseRepository.save(course);
        return ResponseEntity.ok("Course created successfully");
    }

    
    // ✅ Get all courses (active + deleted)
    @GetMapping
    public ResponseEntity<List<CourseEntity>> getAllCourses() {
        return ResponseEntity.ok(courseService.getAllCourses());
    }

    // ✅ Get course by ID
    @GetMapping("/{id}")
    public ResponseEntity<CourseEntity> getById(@PathVariable Long id) {
        return ResponseEntity.ok(courseService.getCourseById(id));
    }

    // ✅ Update Course
    @PutMapping(value = "/{id}", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<CourseEntity> updateCourse(
            @PathVariable Long id,
            @RequestParam("title") String title,
            @RequestParam("description") String description,
            @RequestParam("mrp") BigDecimal mrp,
            @RequestParam("discount") BigDecimal discount,
            @RequestParam("price") BigDecimal price,
            @RequestParam("isFree") boolean isFree,
            @RequestParam("status") String status,
            @RequestParam("subCategoryId") Long subCategoryId,
            @RequestParam(value = "thumbnail", required = false) MultipartFile thumbnail
    ) {
        CourseDTO dto = new CourseDTO();
        dto.setTitle(title);
        dto.setDescription(description);
        dto.setMrp(mrp);
        dto.setDiscount(discount);
        dto.setPrice(price);
        dto.setFree(isFree);
        dto.setStatus(CourseStatus.valueOf(status.toUpperCase()));
        dto.setSubCategoryId(subCategoryId);
        dto.setThumbnail(thumbnail);

        return ResponseEntity.ok(courseService.updateCourse(id, dto));
    }

    // ✅ Soft delete course
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteCourse(@PathVariable Long id) {
        courseService.deleteCourse(id);
        return ResponseEntity.ok("Course soft-deleted");
    }

    // ✅ Restore course
    @PutMapping("/restore/{id}")
    public ResponseEntity<CourseEntity> restoreCourse(@PathVariable Long id) {
        return ResponseEntity.ok(courseService.restoreCourse(id));
    }

    // ✅ Activate course
    @PutMapping("/activate/{id}")
    public ResponseEntity<?> activateCourse(@PathVariable Long id) {
        try {
            CourseEntity activatedCourse = courseService.activateCourse(id);
            return ResponseEntity.ok(activatedCourse);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body((e.getMessage()));
        }
    }

    
    
    

    // ✅ Deactivate course
    @PutMapping("/deactivate/{id}")
    public ResponseEntity<?> deactivateCourse(@PathVariable Long id) {
        try {
            CourseEntity deactivatedCourse = courseService.deactivateCourse(id);
            return ResponseEntity.ok(deactivatedCourse);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body( e.getMessage());
        }
    }
    
    

    // ✅ Make course paid
    @PutMapping("/paid/{id}")
    public ResponseEntity<?> makeCoursePaid(@PathVariable Long id) {
        try {
            CourseEntity paidCourse = courseService.makeCoursePaid(id);
            return ResponseEntity.ok(paidCourse);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(createErrorResponse("Failed to make course paid", e.getMessage()));
        }
    }
    
    
    // ✅ Make course free
    @PutMapping("/free/{id}")
    public ResponseEntity<?> makeCourseFree(@PathVariable Long id) {
        try {
            CourseEntity freeCourse = courseService.makeCourseFree(id);
            return ResponseEntity.ok(freeCourse);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(createErrorResponse("Failed to make course free", e.getMessage()));
        }
    }

    
    

    // ✅ Get paginated courses with filter (active/deleted/all)
    @GetMapping("/paged")
    public ResponseEntity<Page<CourseEntity>> getPagedCourses(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "all") String filter
    ) {
        return ResponseEntity.ok(courseService.getPagedCourses(page, size, filter));
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    private ResponseEntity<?> handleMultipartException(MultipartException e) {
        if (e instanceof MaxUploadSizeExceededException) {
            return ResponseEntity.status(HttpStatus.PAYLOAD_TOO_LARGE)
                    .body(createErrorResponse("File size exceeds maximum limit", e.getMessage()));
        }
        
        if (e.getMessage().contains("FileCountLimitExceededException")) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(createErrorResponse("Too many files in request", 
                            "Please upload files one at a time or reduce the number of files"));
        }
        
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(createErrorResponse("File upload error", e.getMessage()));
    }

    // Helper method to create error response
    private Map<String, Object> createErrorResponse(String message, String details) {
        Map<String, Object> response = new HashMap<>();
        response.put("success", false);
        response.put("message", message);
        response.put("details", details);
        response.put("timestamp", System.currentTimeMillis());
        return response;
    }

    // Helper method to create success response
    private Map<String, Object> createSuccessResponse(String message) {
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("message", message);
        response.put("timestamp", System.currentTimeMillis());
        return response;
    }
    
    
    
    
    
    
    
    
    
    
    
    
}
