package com.mg.admin.contorller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mg.DTO.EnrollmentDTO;
import com.mg.entity.Enrollment;
import com.mg.service1.EnrollmentService;

@RestController
@RequestMapping("/api/admin/enrollments")
public class EnrollmentController 
{
	  @Autowired
	    private EnrollmentService enrollmentService;

	    @GetMapping
	    public ResponseEntity<List<EnrollmentDTO>> getAll() {
	        return ResponseEntity.ok(enrollmentService.getAllEnrollment());
	    }

	    @GetMapping("/active")
	    public ResponseEntity<List<EnrollmentDTO>> getActive() {
	        return ResponseEntity.ok(enrollmentService.getActiveEnrollment());
	    }

	    @PostMapping
	    public ResponseEntity<EnrollmentDTO> create(@RequestBody EnrollmentDTO dto) {
	        return ResponseEntity.ok(enrollmentService.createEnrollment(dto));
	    }

	    @PutMapping("/{id}")
	    public ResponseEntity<EnrollmentDTO> update(@PathVariable Long id, @RequestBody EnrollmentDTO dto) {
	        return ResponseEntity.ok(enrollmentService.updateEnrollment(id, dto));
	    }

	    @DeleteMapping("/{id}")
	    public ResponseEntity<String> delete(@PathVariable Long id) {
	        enrollmentService.deleteEnrollment(id);
	        return ResponseEntity.ok("Enrollment soft-deleted");
	    }

	    @PutMapping("/restore/{id}")
	    public ResponseEntity<Enrollment> restore(@PathVariable Long id) {
	        return ResponseEntity.ok(enrollmentService.restoreEnrollment(id));
	    }

}
