package com.mg.admin.contorller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.mg.DTO.SubCategoryDto;
import com.mg.entity.SubCategory;
import com.mg.service1.SubCategoryService;

@RestController
@RequestMapping("/api/v1/admin/subcategory")
public class SubCategoryController {

    @Autowired
    private SubCategoryService subCategoryService;

    // ✅ Create SubCategory with image and categoryId
    @PostMapping
    public ResponseEntity<SubCategory> create(
            @RequestParam("name") String name,
            @RequestParam("image") MultipartFile image,
            @RequestParam("categoryId") Long categoryId) {

        SubCategoryDto dto = new SubCategoryDto();
        dto.setName(name);

        return ResponseEntity.ok(subCategoryService.createSubCategory(dto, image, categoryId));
    }

    // ✅ Get all subcategories
    @GetMapping
    public ResponseEntity<List<SubCategory>> getAll() {
        return ResponseEntity.ok(subCategoryService.getAllSubCategories());
    }

    // ✅ Get only active subcategories
    @GetMapping("/active")
    public ResponseEntity<List<SubCategory>> getActive() {
        return ResponseEntity.ok(subCategoryService.findByDeletedFalse());
    }

    // ✅ Update SubCategory (with optional image & categoryId)
    @PutMapping("/{id}")
    public ResponseEntity<SubCategory> update(
            @PathVariable Long id,
            @RequestParam("name") String name,
            @RequestParam(value = "image", required = false) MultipartFile image,
            @RequestParam(value = "categoryId", required = false) Long categoryId) {

        SubCategoryDto dto = new SubCategoryDto();
        dto.setName(name);

        return ResponseEntity.ok(subCategoryService.updateSubCategory(id, dto, image, categoryId));
    }

    // ✅ Soft delete subcategory
    @DeleteMapping("/{id}")
    public ResponseEntity<String> delete(@PathVariable Long id) {
        subCategoryService.deleteSubCategory(id);
        return ResponseEntity.ok("SubCategory soft-deleted");
    }

    // ✅ Restore subcategory
    @PutMapping("/restore/{id}")
    public ResponseEntity<SubCategory> restore(@PathVariable Long id) {
        return ResponseEntity.ok(subCategoryService.restoreSubCategory(id));
    }

    // ✅ Deactivate subcategory
    @PutMapping("/deactivate/{id}")
    public ResponseEntity<SubCategory> deactivate(@PathVariable Long id) {
        return ResponseEntity.ok(subCategoryService.deactivateSubCategory(id));
    }

    // ✅ Activate subcategory
    @PutMapping("/activate/{id}")
    public ResponseEntity<SubCategory> activate(@PathVariable Long id) {
        return ResponseEntity.ok(subCategoryService.activateSubCategory(id));
    }

    // ✅ Paginated subcategory list (all/active/deleted)
    @GetMapping("/paged")
    public ResponseEntity<Page<SubCategory>> getPaged(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "all") String filter // all | active | deleted
    ) {
        return ResponseEntity.ok(subCategoryService.getPagedSubCategories(page, size, filter));
    }

    // ✅ Search with filter and pagination
    @GetMapping("/search")
    public ResponseEntity<Page<SubCategory>> search(
            @RequestParam(defaultValue = "") String name,
            @RequestParam(defaultValue = "all") String filter,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        return ResponseEntity.ok(subCategoryService.searchSubCategories(name, filter, page, size));
    }

    // ✅ Get by ID
    @GetMapping("/{id}")
    public ResponseEntity<SubCategory> getById(@PathVariable Long id) {
        return ResponseEntity.ok(subCategoryService.getSubCategoryById(id));
    }
}
