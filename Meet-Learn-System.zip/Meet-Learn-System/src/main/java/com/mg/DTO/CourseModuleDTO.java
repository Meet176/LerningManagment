package com.mg.DTO;



import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CourseModuleDTO 
{
	private Long id;
	private Long CourseId;
	private String title;
	private Integer contentCount;
	private String total_length;
	 private String details;
	 private int serialNumber;
	private Boolean isFree = true;
}





