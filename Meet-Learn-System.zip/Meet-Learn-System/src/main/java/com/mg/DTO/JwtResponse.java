package com.mg.DTO;
import lombok.Data;

@Data
public class JwtResponse {
    private String token;
    private String role;
    private String fullname;
}