package com.mg.DTO;

import lombok.*;

import java.math.BigDecimal;

import org.springframework.web.multipart.MultipartFile;
import com.mg.entity.CourseStatus;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CourseDTO {
    private Long subCategoryId;
    private Long instructor;
    private String title;
    private String description;
    private BigDecimal mrp;
    private BigDecimal discount;
    private BigDecimal price;
    private MultipartFile thumbnail;
    private boolean isFree;
    private CourseStatus status;
}
