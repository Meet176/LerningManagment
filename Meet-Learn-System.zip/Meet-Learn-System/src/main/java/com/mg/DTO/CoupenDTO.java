package com.mg.DTO;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import com.mg.enums.DiscountType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CoupenDTO 
{
		private Long id;
		private String code;
		private DiscountType  discountType;
		private BigDecimal discountAmount;
		private LocalDateTime expirydate;
}
