package com.mg.DTO;


import lombok.Data;

@Data
public class NotificationDTO 
{
	private Long id;
	private String msg;
	private String type;
	private Long userid;
	private Boolean  isRead;
}
