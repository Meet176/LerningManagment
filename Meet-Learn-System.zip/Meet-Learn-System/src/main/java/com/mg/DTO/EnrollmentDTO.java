package com.mg.DTO;

import java.math.BigDecimal;
import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class EnrollmentDTO 
{
	private Long userId;
	private Long courseID;
	private LocalDate enrollmentDate;
	private Boolean isCompleted;
	private BigDecimal price;
	private String paymentMethod;
	private String couponCode;
    private String appliedCoupon; 
}
