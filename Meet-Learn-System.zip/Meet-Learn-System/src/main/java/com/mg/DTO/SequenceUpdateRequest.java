package com.mg.DTO;

import lombok.Data;

@Data
public class SequenceUpdateRequest 
{
	private Long id;
	private int sequence;;
}
