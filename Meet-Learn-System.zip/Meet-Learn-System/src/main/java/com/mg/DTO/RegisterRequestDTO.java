package com.mg.DTO;


import com.mg.entity.Role;

import lombok.Data;

@Data
public class RegisterRequestDTO 
{
    
	private String fullname;
    private String email;
    private String password;
    private String phone;
    private Role role;
    
    
    
    
}