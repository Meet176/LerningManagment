package com.mg.security;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer 
{

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry
            .addResourceHandler("/images/**")
            .addResourceLocations("file:./uploads/");
        
        
        
        registry
        .addResourceHandler("/videos/**")
        .addResourceLocations("file:./uploads/videos/");
        
        
        

    }
    
    @Override
    public void addCorsMappings(org.springframework.web.servlet.config.annotation.CorsRegistry registry) {
        registry.addMapping("/images/**")
                .allowedOrigins("http://localhost:3000")
                .allowedMethods("GET");
        
        
        registry.addMapping("/videos/**")
        .allowedOrigins("http://localhost:3000")
        .allowedMethods("GET")
        .allowCredentials(true);
        
       
        
    }

}