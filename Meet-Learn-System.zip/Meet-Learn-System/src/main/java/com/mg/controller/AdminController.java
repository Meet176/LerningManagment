package com.mg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mg.DTO.RegisterRequestDTO;
import com.mg.entity.UserEntity;
import com.mg.service1.UserService;

@RestController
@RequestMapping("/api/v1/admin")
public class AdminController 
{
	@Autowired
	private UserService userService;
	
	
	@GetMapping("/instructors")
    public List<UserEntity> getAllInstructors() {
        return userService.getAllInstructors();
    }
}
