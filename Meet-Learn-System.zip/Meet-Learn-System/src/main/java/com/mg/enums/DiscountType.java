package com.mg.enums;

public enum DiscountType 
{
	Percentage,
    Flat
}
