package com.mg.mapper;

import org.springframework.stereotype.Component;

import com.mg.DTO.CoupenDTO;
import com.mg.entity.Coupen;

@Component
public class CoupenMapper 
{
		public  Coupen toEntity(CoupenDTO dto)
		{
			
			Coupen coupen =  new Coupen();
			
			coupen.setCode(dto.getCode());
			coupen.setDiscountAmount(dto.getDiscountAmount());
			coupen.setDiscountType(dto.getDiscountType());
			coupen.setExpiryDate(dto.getExpirydate());
			
			return coupen;
			
		}
		
		
		
		public CoupenDTO toDto(Coupen coupen)
		{
			CoupenDTO dto =  new CoupenDTO();
			
			
			dto.setCode(coupen.getCode());
			dto.setId(coupen.getId());
			dto.setDiscountAmount(coupen.getDiscountAmount());
			dto.setDiscountType(coupen.getDiscountType());
			dto.setExpirydate(coupen.getExpiryDate());
			
			return dto;
		}
}
