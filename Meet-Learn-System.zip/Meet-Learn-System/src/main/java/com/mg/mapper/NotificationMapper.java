package com.mg.mapper;

import org.springframework.stereotype.Component;

import com.mg.DTO.NotificationDTO;
import com.mg.entity.Notification;
import com.mg.entity.UserEntity;

@Component
public class NotificationMapper {

    // Convert DTO to Entity
    public Notification toEntity(NotificationDTO dto, UserEntity user) {
        Notification notification = new Notification();

        notification.setId(dto.getId());
        notification.setMsg(dto.getMsg());
        notification.setType(dto.getType());
        notification.setUser(user);
        notification.setRead(dto.getIsRead());

        return notification;
    }

    // Convert Entity to DTO
    public NotificationDTO toDto(Notification notification) {
        NotificationDTO dto = new NotificationDTO();

        dto.setId(notification.getId());
        dto.setMsg(notification.getMsg());
        dto.setType(notification.getType());

        if (notification.getUser() != null) {
            dto.setUserid(notification.getUser().getId());
        }

        dto.setIsRead(notification.isRead());

        return dto;
    }
}
