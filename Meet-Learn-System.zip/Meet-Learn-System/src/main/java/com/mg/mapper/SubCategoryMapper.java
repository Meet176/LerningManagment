//package com.mg.mapper;
//
//import org.springframework.stereotype.Component;
//
//import com.mg.DTO.SubCategoryDto;
//import com.mg.entity.Category;
//import com.mg.entity.SubCategory;
//
//@Component
//public class SubCategoryMapper 
//{
//		public  SubCategory toEntity(SubCategoryDto dto,Category category)
//		{
//			SubCategory subcategory =  new SubCategory();
//			
//			
//			subcategory.setCategory(category);
//			
//			subcategory.setName(dto.getName());
//			
//			
//			subcategory.setImage(dto.getImage());
//			
//			return subcategory;
//		}
//		
//		public  SubCategoryDto toDto(SubCategory subcategory)
//		{
//			
//			SubCategoryDto dto = new SubCategoryDto();
//			
//			 dto.setId(subcategory.getId());
//		        dto.setName(subcategory.getName());
//		        dto.setImage(subcategory.getImage());
//		        dto.setCategoryId(subcategory.getCategory().getId());
//		        
//		        return dto;
//			
//		}
//	
//}
