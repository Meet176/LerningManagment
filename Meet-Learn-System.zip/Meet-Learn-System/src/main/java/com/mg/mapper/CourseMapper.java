//package com.mg.mapper;
//
//import org.springframework.stereotype.Component;
//
//import com.mg.DTO.CourseDTO;
//import com.mg.entity.CourseEntity;
//import com.mg.entity.SubCategory;
//import com.mg.entity.UserEntity;
//
//import lombok.RequiredArgsConstructor;
//
//@Component
//@RequiredArgsConstructor
//public class CourseMapper 
//{
//	public CourseEntity toEntity(CourseDTO dto,SubCategory subcategory,UserEntity userentity)
//	{
//		CourseEntity course = new CourseEntity();
//		
//		course.setId(dto.getId());
//		course.setSubcategory(subcategory);
//		course.setUserEntity(userentity);
//		course.setTitle(dto.getTitle());
//		course.setDescription(dto.getDscription());
//		course.setMrp(dto.getMrp());
//		course.setDiscount(dto.getDiscount());
//		course.setPrice(dto.getPrice());
//		course.setThumbnail(dto.getThumbnail());
//		course.setIsFree(dto.getIsFree());
//		course.setStatus(dto.getStatus());
//		
//		return course;
//		
//	}
//		public CourseDTO toDto(CourseEntity course)
//		{
//			CourseDTO dto  = new CourseDTO();
//			
//			dto.setId(course.getId());
//			dto.setSubCategoryId(course.getSubcategory().getId());
//			dto.setUserId(course.getUserEntity().getId());
//			dto.setTitle(course.getTitle());
//	        dto.setDscription(course.getDescription());
//	        dto.setMrp(course.getMrp());
//	        dto.setDiscount(course.getDiscount());
//	        dto.setPrice(course.getPrice());
//	        dto.setThumbnail(course.getThumbnail());
//	        dto.setIsFree(course.getIsFree());
//	        dto.setStatus(course.getStatus());
//			
//			return dto;
//		}
//
//}
