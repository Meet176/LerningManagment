package com.mg.mapper;

import org.springframework.stereotype.Component;

import com.mg.DTO.EnrollmentDTO;
import com.mg.entity.CourseEntity;
import com.mg.entity.Enrollment;
import com.mg.entity.UserEntity;

@Component
public class EnrollmentMapper {

    public Enrollment toEntity(EnrollmentDTO dto, UserEntity student, CourseEntity course) {
        Enrollment enrollment = new Enrollment();

        enrollment.setStudent(student);
        enrollment.setCourse(course);
        enrollment.setEnrollment(dto.getEnrollmentDate());
        enrollment.setIsCompleted(dto.getIsCompleted());
        enrollment.setPrice(dto.getPrice());
        enrollment.setPaymentMethod(dto.getPaymentMethod());
        enrollment.setApplicationCoupone(dto.getAppliedCoupon());

        return enrollment;
    }

    public EnrollmentDTO toDto(Enrollment enrollment) {
        EnrollmentDTO dto = new EnrollmentDTO();

        dto.setUserId(enrollment.getStudent() != null ? enrollment.getStudent().getId() : null);
        dto.setCourseID(enrollment.getCourse() != null ? enrollment.getCourse().getId() : null);
        dto.setEnrollmentDate(enrollment.getEnrollment());
        dto.setIsCompleted(enrollment.getIsCompleted());
        dto.setPrice(enrollment.getPrice());
        dto.setPaymentMethod(enrollment.getPaymentMethod());
        dto.setAppliedCoupon(enrollment.getApplicationCoupone());

        return dto;
    }
}
