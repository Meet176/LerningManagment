//package com.mg.mapper;
//
//import org.springframework.stereotype.Component;
//
//import com.mg.DTO.CategoryDto;
//import com.mg.entity.Category;
//
//@Component
//public class CategoryMapper 
//{
//
//		public Category toEntity(CategoryDto dto)
//		{
//			Category  category =  new Category();
//			
//			category.setId(dto.getId());
//			
//			category.setName(dto.getName());
//			
//			category.setImage(dto.getImage());
//			return category;
//		}
//		
//		
//		public CategoryDto toDto(Category category)
//		{
//			CategoryDto dto =  new CategoryDto();
//			
//			dto.setId(category.getId());
//			
//			dto.setName(category.getName());
//			
//			dto.setImage(category.getImage());
//			
//			return dto;
//		}
//	
//}
