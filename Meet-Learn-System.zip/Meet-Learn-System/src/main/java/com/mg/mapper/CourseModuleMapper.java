package com.mg.mapper;

import org.springframework.stereotype.Component;

import com.mg.DTO.CourseModuleDTO;
import com.mg.entity.CourseEntity;
import com.mg.entity.CourseModule;

@Component
public class CourseModuleMapper 
{
	
	
		public CourseModule toEntity(CourseModuleDTO dto,CourseEntity courseEntity)
		{
			
			CourseModule module =  new CourseModule();
			
				
			module.setTitle(dto.getTitle());
			module.setContentCount(dto.getContentCount());
			module.setDetails(dto.getDetails());
			module.setTotalLength(dto.getTotal_length());
			module.setIsFree(dto.getIsFree());
			module.setSerialNumber(dto.getSerialNumber());
			module.setCourse(courseEntity);
	
			return module;
				
		}
		
		
		public CourseModuleDTO toDTO(CourseModule module)
		{
			CourseModuleDTO dto = new  CourseModuleDTO();
			
			
			dto.setId(module.getId());
			dto.setTitle(module.getTitle());
			dto.setContentCount(module.getContentCount());
			dto.setTotal_length(module.getTotalLength());
			dto.setIsFree(module.getIsFree());
			dto.setDetails(module.getDetails());
			dto.setSerialNumber(module.getSerialNumber());
			if(module.getCourse()!=null)
				dto.setCourseId(module.getCourse().getId());
			
			return dto;
		}


		
	
}
