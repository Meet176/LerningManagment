package com.mg.mapper;

import org.springframework.stereotype.Component;

import com.mg.DTO.CourseContentDTO;
import com.mg.entity.CourseContent;
import com.mg.entity.CourseModule;

@Component
public class CourseContentMapper {

    // Map DTO to Entity
    public CourseContent toEntity(CourseContentDTO dto, CourseModule module, String storedFilePath) {
        CourseContent entity = new CourseContent();

        entity.setId(dto.getId());
        entity.setTitle(dto.getTitle());
        entity.setSequence(dto.getSequence());
        entity.setFileType(dto.getFileType());
        entity.setIsFree(dto.getIsFree());
        entity.setDurationMinutes(dto.getDurationMinutes());
        entity.setFilePath(storedFilePath); // Save uploaded file name/path
        entity.setCourseModule(module);

        return entity;
    }

    // Map Entity to DTO
    public CourseContentDTO toDTO(CourseContent entity) {
        CourseContentDTO dto = new CourseContentDTO();

        dto.setId(entity.getId());
        dto.setTitle(entity.getTitle());
        dto.setSequence(entity.getSequence());
        dto.setFileType(entity.getFileType());
        dto.setIsFree(entity.getIsFree());
        dto.setDurationMinutes(entity.getDurationMinutes());
        dto.setModuleId(entity.getCourseModule().getId());

        // Not setting `filepath` in DTO (because it is MultipartFile and only needed during upload)

        return dto;
    }
}
