package com.mg.instructore.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mg.DTO.NotificationDTO;
import com.mg.entity.Notification;
import com.mg.entity.UserEntity;
import com.mg.exception.ResourceNotFoundException;
import com.mg.instructore.service.InstructoreNotificationService;
import com.mg.mapper.NotificationMapper;
import com.mg.repository.NotificationRepository;
import com.mg.repository.UserRepository;

@Service
public class InstructoreNotificationServiceImpl implements InstructoreNotificationService  	
{
	@Autowired
	private NotificationRepository notificationRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private NotificationMapper mapper;

	@Override
	public NotificationDTO createNotification(NotificationDTO dto) 
	{
		UserEntity user = userRepository.findById(dto.getUserid()).orElseThrow(()-> new ResourceNotFoundException("The Recipient Not Found...."));
		return mapper.toDto(notificationRepository.save(mapper.toEntity(dto, user)));
	}

	@Override
	public List<Notification> getInstructoreNotification(Long instructorId) 
	{
		return notificationRepository.findByUserIdOrderByCreatedDateDesc(instructorId);
		
	}

	@Override
	public NotificationDTO UpadateNotification(Long id, NotificationDTO dto) 
	{
			Notification notification = notificationRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("The  Notification Not Found to Update"));
		return mapper.toDto(notificationRepository.save(mapper.toEntity(dto, null)));
	}

	@Override
	public void deleteNotification(Long id) 
	{
		notificationRepository.deleteById(id);
	}

}
