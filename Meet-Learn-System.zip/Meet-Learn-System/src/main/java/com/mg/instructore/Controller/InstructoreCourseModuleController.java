package com.mg.instructore.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mg.DTO.CourseModuleDTO;
import com.mg.entity.CourseModule;
import com.mg.instructore.service.InstructoreModuleService;

@RestController
@RequestMapping("/api/instructor")
public class InstructoreCourseModuleController 
{
		@Autowired
		private InstructoreModuleService Service;
		
		
		@GetMapping("/coures/{courseId}/modules")
		public ResponseEntity<List<CourseModule>> getModule(@PathVariable("courseId") Long coursId)
		{
			return ResponseEntity.ok(Service.getModuleByCourseId(coursId));
		}
		
		@PutMapping("/module/{id}")
		public ResponseEntity<CourseModuleDTO> UpdateModule(@PathVariable("id") Long id,@RequestBody CourseModuleDTO dto)
		{
				
			return ResponseEntity.ok(Service.updatemodule(id, dto));
		}

}
