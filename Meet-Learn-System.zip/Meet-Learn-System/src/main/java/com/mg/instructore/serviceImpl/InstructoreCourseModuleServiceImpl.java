package com.mg.instructore.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mg.DTO.CourseModuleDTO;
import com.mg.entity.CourseModule;
import com.mg.exception.ResourceNotFoundException;
import com.mg.instructore.service.InstructoreModuleService;
import com.mg.mapper.CourseModuleMapper;
import com.mg.repository.CourseModuleRepository;

@Service
public class InstructoreCourseModuleServiceImpl implements InstructoreModuleService 
{
	
	@Autowired
	private CourseModuleRepository repo;
	
	@Autowired
	private CourseModuleMapper mapper;
	
	@Override
	public List<CourseModule> getModuleByCourseId(Long courseid) 
	{
		return repo.findByCourseIdAndDeletedDateIsNull(courseid);
	}

	@Override
	public CourseModuleDTO updatemodule(Long id, CourseModuleDTO dto) 
	{
		CourseModule module = repo.findById(id).orElseThrow(()-> new ResourceNotFoundException("The Course Module Not Found..."));
		return mapper.toDTO(repo.save(mapper.toEntity(dto, null)));
	}

}
