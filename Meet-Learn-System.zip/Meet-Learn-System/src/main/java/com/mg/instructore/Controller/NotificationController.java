package com.mg.instructore.Controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mg.DTO.NotificationDTO;
import com.mg.entity.Notification;
import com.mg.instructore.service.InstructoreNotificationService;

import jakarta.websocket.server.PathParam;

@RestController
@RequestMapping("/api/instructore/notifications")
public class NotificationController 
{

	@Autowired
	private InstructoreNotificationService service;
	
	@GetMapping
	public ResponseEntity<List<Notification>> getAll(Principal principal)
	{
		Long instructorId = getUserIdFromPrincipal(principal);
		
		return ResponseEntity.ok(service.getInstructoreNotification(instructorId));
	}

	@PostMapping
	public ResponseEntity<NotificationDTO>create(@RequestBody NotificationDTO dto)
	{
		return ResponseEntity.ok(service.createNotification(dto));
	}
	
	
	@PutMapping("/{id}")
	public ResponseEntity<NotificationDTO> Update(@PathVariable("id") Long id, @RequestBody  NotificationDTO dto)
	{
		return ResponseEntity.ok(service.UpadateNotification(id, dto));
	}
	
	// Delete
    @DeleteMapping("/{id}")
    public ResponseEntity<String> delete(@PathVariable Long id)
    {
        service.deleteNotification(id);
        return ResponseEntity.ok("Notification deleted");
    }
	
	
	
	
	
	
	
	private Long getUserIdFromPrincipal(Principal principal)
	{
		return 2L;
	}
	
}
