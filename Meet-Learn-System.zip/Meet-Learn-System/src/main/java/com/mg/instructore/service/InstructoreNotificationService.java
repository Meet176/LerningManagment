package com.mg.instructore.service;

import java.util.List;

import com.mg.DTO.NotificationDTO;
import com.mg.entity.Notification;

public interface InstructoreNotificationService 
{
	NotificationDTO createNotification(NotificationDTO dto);
	List<Notification> getInstructoreNotification(Long instructorId);
	NotificationDTO UpadateNotification(Long id,NotificationDTO dto);
	void deleteNotification(Long id);
	
}
