package com.mg.instructore.service;

import java.util.List;

import com.mg.DTO.CourseModuleDTO;
import com.mg.entity.CourseModule;

public interface InstructoreModuleService 
{
	List<CourseModule> getModuleByCourseId(Long courseid);
	CourseModuleDTO updatemodule(Long id,CourseModuleDTO dto);
}
