package com.mg.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST)
public class UserAlreadyExisitException extends RuntimeException
{
	
	public UserAlreadyExisitException(String message)
	{
		super(message);
	}

}
