package com.mg.exception;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandller 
{
	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<?> handlNotFound(ResourceNotFoundException ex)
	{
		Map<String, Object> error = new HashMap<>();
		
		
		error.put("timestamp",LocalDateTime.now());
		error.put("status",HttpStatus.NOT_FOUND.value());
		error.put("message",ex.getMessage());
		
		return new ResponseEntity<>(error,HttpStatus.NOT_FOUND);
	}
	
	

	@ExceptionHandler(PrimaryRefranceNotAvailableExcdption.class)
	public ResponseEntity<?> handlPrimaryRefranceNotFound(PrimaryRefranceNotAvailableExcdption ex)
	{
		Map<String, Object> error = new HashMap<>();
		
		
		error.put("timestamp",LocalDateTime.now());
		error.put("status",HttpStatus.BAD_REQUEST.value()+ex.getMessage());
		error.put("message",ex.getMessage());
		
		return new ResponseEntity<>(error,HttpStatus.BAD_REQUEST);
	}


	
	@ExceptionHandler(RecordAlreadyExisitException.class)
	public ResponseEntity<?> handlRecordAlreadyExisit( RecordAlreadyExisitException ex)
	{
		Map<String, Object> error = new HashMap<>();
		
		
		error.put("timestamp",LocalDateTime.now());
		error.put("status",HttpStatus.FOUND.value());
		error.put("message",ex.getMessage());
		
		return new ResponseEntity<>(error,HttpStatus.FOUND);
	}
	
	
	
	@ExceptionHandler(UserAlreadyExisitException.class)
	public ResponseEntity<?> handlUserAlreadyExisit( UserAlreadyExisitException ex)
	{
		Map<String, Object> error = new HashMap<>();
		
		
		error.put("timestamp",LocalDateTime.now());
		error.put("status",HttpStatus.BAD_REQUEST.value());
		error.put("message",ex.getMessage());
		
		return new ResponseEntity<>(error,HttpStatus.BAD_REQUEST);
	}
	
	
	
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<?> handlGeneric(Exception ex)
	{
		Map<String, Object> error = new HashMap<>();
		
		
		error.put("timestamp",LocalDateTime.now());
		error.put("status",HttpStatus.INTERNAL_SERVER_ERROR.value());
		error.put("message","An excepted Error Ocuured"+ex.getMessage());
			
		
		return new ResponseEntity<>(error,HttpStatus.INTERNAL_SERVER_ERROR);
		
	}
}
