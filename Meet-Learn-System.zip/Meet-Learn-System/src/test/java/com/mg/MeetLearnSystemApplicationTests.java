package com.mg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeetLearnSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
